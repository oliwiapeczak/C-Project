﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Logika interakcji dla klasy Serial.xaml
    /// </summary>
    public partial class Serial : Window
    {
        Portal portal;
        Konto konto;
        public Serial()
        {
            InitializeComponent();
        }

        public Serial(Projekt.Serial s, Konto k, Portal p) :this()
        {
            konto = k;
            portal = p;
            lbl_TYTUL.Content = s.Tytul;
            lbl_REZYSER.Content = s.Rezyser;
            lbl_ROK.Content = s.Rok;
            lbl_ODCINKI.Content = s.Liczba_odcinkow;
            lbl_SEZONY.Content = s.Liczba_sezonow;
            lbl_kategoria.Content = s.Gatunek;
            tblock_OPIS.Text = s.Opis;
        }

        private void Button_Click_Wroc(object sender, RoutedEventArgs e)
        {
            Katalog katalog = new Katalog(konto, portal);
            Close();
            katalog.ShowDialog();
        }
    }
}
