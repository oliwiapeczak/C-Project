﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Projekt
{
    /// <summary>
    /// Typ wyliczeniowy dla płuci.
    /// </summary>
    public enum Plcie { Mezczyzna, Kobieta }
    /// <summary>
    /// Publiczna klasa Uzytkownik.
    /// Dziedzicząca po  IEquatable<Uzytkownik>,ICloneable.
    /// </summary>
    
    [Serializable]
    public class Uzytkownik : ICloneable
    {
        string imie;
        string nazwisko;
        string email;
        DateTime dataUr;
        Plcie plec;

        public string Imie { get => imie; set => imie = value; }
        public string Nazwisko { get => nazwisko; set => nazwisko = value; }
        public string Email { get => email; set => email = value; }
        public DateTime DataUr { get => dataUr; set => dataUr = value; }
        public Plcie Plec { get => plec; set => plec = value; }

        public Konto Konto
        {
            get => default;
            set
            {
            }
        }

        /// <summary>Tworzy konstruktor klasy Użytkownik o parametrach:imię, nazwisko, email, dataUr i numer telefonu oraz inicjalizuje dane. </summary>
        public Uzytkownik()
        {
            imie = null;
            nazwisko = null;
            email = null;
            dataUr = DateTime.Now;
        }

        /// <summary>Konstruktor klasy Uzytkownik inicjalizujący dane na podane wartości i sprawdzający poprawność datu urodzenia, emaila i numeru telefonu.</summary>
        /// <param name="imie">Imie.</param>
        /// <param name="nazwisko">Nazwisko.</param>
        /// <param name="dataUr">Data urodzenia.</param>
        /// <param name="email">Email.</param>
        /// <param name="plec">Płeć</param>
        public Uzytkownik(string imie, string nazwisko, string dataUr, string email, Plcie plec, uint numer)
        {
            SetImie(imie);
            SetNazwisko(nazwisko);
            Plec = plec;
            DateTime.TryParseExact(dataUr, new[] { "dd/MM/yyyy", "dd-MM-yyyy", "dd.MM.yyyy" }, null, DateTimeStyles.None, out this.dataUr);
            SetEmail(email);
        }

        public void SetImie(string imie)
        {
            Regex reg = new Regex(@"^[A-Z][a-z]+$");
            if (reg.IsMatch(imie)) { Imie = imie; } else { throw new Exception("Niepoprawne imie!!"); }
        }
        public void SetNazwisko(string nazw)
        {
            Regex reg = new Regex(@"^[A-Z][a-z]+$");
            if (reg.IsMatch(nazw)) { Nazwisko = nazw; } else { throw new Exception("Niepoprawne nazwisko!!"); }
        }

        /// <summary>Sprawdzanie poprawności emaila poprzez ustawienie wzoru. wyrzuca wyjątek w przypadku błędnego emiala.</summary>
        /// <param name="mail"> Email.</param>
        /// <exception cref="Exception">Niepoprawny mail!!</exception>
        void SetEmail(string mail)
        {
            Regex reg = new Regex(@"^[A-Za-z0-9]+@[a-z]+.[a-z]+$");
            if (reg.IsMatch(mail)) { Email = mail; } else { throw new Exception("Niepoprawny mail!!"); }
        }

        /// <summary>Funkcja wyliczjąca wiek.</summary>
        /// <returns>System.Int32 mówiący o wieku.</returns>
        public int Wiek()
        {
            return (DateTime.Now.Year - DataUr.Year);
        }
        /// <summary>
        /// Zwraca ciąg wyrazów, który reprezentuje bieżący obiekt. Pozwala na wypisywanie.
        /// </summary>
        /// <returns>Zwraca ciąg, który reprezentuje bieżący obiekt.</returns>
        public override string ToString()
        {
            return $"{imie} {nazwisko}, wiek: {Wiek().ToString()}, ur. {dataUr.ToShortDateString()}, plec: {plec}, e-mail: {email}";
        }

        /// <summary>Tworzy nowy obiekt,który pozwala na skopiowanie zwartości całego użytkownika.</summary>
        /// <returns>Nowy obiekt,który jest kopią użytkownika.</returns>
        public object Clone()
        {
            return this.MemberwiseClone();
        }

        
    }
}
