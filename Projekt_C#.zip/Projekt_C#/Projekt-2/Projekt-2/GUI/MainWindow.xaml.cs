﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Logika interakcji dla klasy Logowanie.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Portal p;
        List<Konto> lista = new List<Konto>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_zerejestruj_Click(object sender, RoutedEventArgs e)
        {
            Rejestracja rej = new Rejestracja();
            rej.Show();
            Close();
        }

        private void btn_zaloguj_Click(object sender, RoutedEventArgs e)
        {
            p = new Portal();
            p = (Portal)p.OdczytajXML("portal.xml");
            lista = p.Uzytkownicy;
            string haslo = pb_hasloLog.Password;
            string login = txt_loginLog.Text;
            foreach (Konto k in lista)
            {
                if (k.Login == login)
                {
                    if (k.Haslo == haslo)
                    {
                        użytkownik uzy = new użytkownik(k, p);
                        Close();
                        uzy.ShowDialog();
                        return;
                    }
                    
                    else { MessageBox.Show("Bledne haslo!", "BŁĄD!", MessageBoxButton.OK, MessageBoxImage.Error); return; }
                }
            }
            foreach(Konto k in lista)
            {
                if (k.Login != login)
                {
                  MessageBox.Show("Nie ma uzytkownika o takim loginie!","BŁĄD!", MessageBoxButton.OK,MessageBoxImage.Error); return; 
                }
            }
            
        }
    }
}
