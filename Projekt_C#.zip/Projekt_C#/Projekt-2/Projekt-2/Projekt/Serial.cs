﻿using System;
using System.Xml.Serialization;

namespace Projekt
{
    [XmlInclude(typeof(Film))]
    [Serializable]
    public class Serial : Film
    {
        uint liczba_sezonow;
        uint liczba_odcinkow;

        public uint Liczba_sezonow { get => liczba_sezonow; set => liczba_sezonow = value; }
        public uint Liczba_odcinkow { get => liczba_odcinkow; set => liczba_odcinkow = value; }


        /// <summary>Tworzy konstruktor klasy Serial o prametrach liczba sezonów i liczba odcinków. Inicjalizuje dane.</summary>
        public Serial()
        {
            Liczba_sezonow = 1;
            Liczba_odcinkow = 1;
        }

        /// <summary>Tworzy konstruktor, który dziedziczy po klasie film.</summary>
        /// <param name="tytul">Tytul.</param>
        /// <param name="rezyser">Rezyser.</param>
        /// <param name="rok">Rok.</param>
        /// <param name="ograniczenie_wiekowe">Ograniczenie wiekowe.</param>
        /// <param name="gatunek">Gatunek.</param>
        /// <param name="sezony">Sezony.</param>
        /// <param name="odcinki">Odcinki.</param>
        public Serial(string tytul, string rezyser, int rok, int ograniczenie_wiekowe, Gatunek gatunek, string opis, uint sezony, uint odcinki) : base(tytul, rezyser, rok, ograniczenie_wiekowe, gatunek, opis)
        {
            Liczba_sezonow = sezony;
            Liczba_odcinkow = odcinki;
        }

        /// <summary>
        /// Zwraca ciąg wyrazów, który reprezentuje bieżący obiekt. Pozwala na wypisywanie.
        /// </summary>
        /// <returns>Zwraca ciąg, który reprezentuje bieżący obiekt.</returns>
        public override string ToString()
        {
            return base.ToString();
        }

        /// <summary>
        /// Tworzy nowy obiekt,który pozwala na skopiowanie zwartości całej instancji.Kopiuje tą instancję.
        /// </summary>
        /// <returns>Nowy obiekt,który jest kopią.</returns>
        public object Clone(Serial s)
        {
            return s.MemberwiseClone();
        }


    }
}
