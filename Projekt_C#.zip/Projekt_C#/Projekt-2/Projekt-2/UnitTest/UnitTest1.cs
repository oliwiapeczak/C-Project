﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Projekt;
namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void NazwaTest()
        {
            string tytul1 = "Faceci w Czerni";
            Film f1 = new Film("Faceci w Czerni", "jakisrezyser", 1997, 13, Gatunek.Komedia, "aaaa");
            Assert.AreEqual(tytul1, f1.Tytul);
        }

        [TestMethod]
        public void LicznikTest()
        {
            Uzytkownik u1 = new Uzytkownik("Anna", "Nowak", "12.03.1998", "Ania12@gmail.com", Plcie.Kobieta, 123123123);
            Konto k1 = new Konto(u1, "ania", "qwe123");
            Portal p1 = new Portal("Siszarpix");
            p1.DodajKonto(k1);

            int ilosc = p1.liczbaUzytkownikow();
            

            Assert.AreEqual(1, ilosc);

        }

        [TestMethod]
        public void OsobaCompareToTest()
        {
            Uzytkownik u1 = new Uzytkownik("Anna", "Nowak", "12.03.1998", "Ania12@gmail.com", Plcie.Kobieta, 123123123);
            Uzytkownik u2 = new Uzytkownik("Kacper", "Kowalski", "03.06.2006", "Kacper05@gmail.com", Plcie.Mezczyzna, 123123123);

            Assert.AreEqual(true, u1.Equals(u2));
        }
        

    }
}
