﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Logika interakcji dla klasy Dane.xaml
    /// </summary>
    public partial class Dane : Window
    {
        Konto konto;
        Portal portal;

        public Dane()
        {
            InitializeComponent();
        }

        public Dane(Konto k, Portal p) : this()
        {
            konto = k;
            portal = p;
            txt_dataur.Text = k.Uzytkownik1.DataUr.ToShortDateString();
            txt_imieinazw.Text = k.Uzytkownik1.Imie + " " + k.Uzytkownik1.Nazwisko;
            txt_login.Text = k.Login;
            txt_mail.Text = k.Uzytkownik1.Email;
            txt_plec.Text = k.Uzytkownik1.Plec.ToString();
        }

        private void btn_wroc_Click(object sender, RoutedEventArgs e)
        {
            użytkownik uzy = new użytkownik(konto, portal);
            Close();
            uzy.ShowDialog();
        }

        private void btn_zmienhaslo_Click(object sender, RoutedEventArgs e)
        {
            ZmianaHasla zmiana = new ZmianaHasla(konto, portal);
            Close();
            zmiana.ShowDialog();
        }
    }
}
