﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Logika interakcji dla klasy Film.xaml
    /// </summary>
    public partial class Film : Window
    {
        Portal portal;
        Konto konto;

        public Film()
        {
            InitializeComponent();
        }

        public Film(Projekt.Film f, Konto k, Portal p) : this()
        {
            portal = p;
            konto=k;
            lbl_KATEGORIAF.Content = f.Gatunek;
            lbl_REZYSERF.Content = f.Rezyser;
            lbl_ROKF.Content = f.Rok;
            lbl_TYTULF.Content = f.Tytul;
            tblock_OPIS.Text = f.Opis;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Katalog katalog = new Katalog(konto, portal);
            Close();
            katalog.ShowDialog();
        }
    }
}
