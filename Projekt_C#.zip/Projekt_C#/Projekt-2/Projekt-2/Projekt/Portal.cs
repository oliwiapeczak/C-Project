﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Projekt
{
    /// <summary>Publiczna klasa Portal dziedzicząca po interfejsie IZapisywalny.
    /// </summary>
    /// <seealso cref="Projekt.IZapisywalny" />
    [XmlInclude(typeof(Serial))]
    [Serializable]
    public class Portal: IZapisywalny
    {
        string nazwa_portalu;
        List<Konto> uzytkownicy;
        List<Film> bazaFilmow;

        public List<Konto> Uzytkownicy { get => uzytkownicy; set => uzytkownicy = value; }
        public string Nazwa_portalu { get => nazwa_portalu; set => nazwa_portalu = value; }
        public List<Film> BazaFilmow { get => bazaFilmow; set => bazaFilmow = value; }

        public Konto Konto
        {
            get => default;
            set
            {
            }
        }

        public Serial Serial
        {
            get => default;
            set
            {
            }
        }

        public Film Film
        {
            get => default;
            set
            {
            }
        }

        /// <summary>Konstruktor klasy portal inicjalizujący listę użytkowników.</summary>
        public Portal()
        {
            Uzytkownicy = new List<Konto>();
            BazaFilmow = new List<Film>();
        }

        /// <summary>Konstruktor klasy Portal inicjalizujący nazwę na podaną.</summary>
        /// <param name="nazwa">Nazwa.</param>
        public Portal(string nazwa):this()
        {
            Nazwa_portalu = nazwa;
        }

        //REJESTRACJA
        /// <summary>Funkcja rejestracji użytkownika. Sprawdza czy już taki użytkownik nie wystąpił.</summary>
        /// <param name="k">Nowe konto k.</param>
        public void DodajKonto(Konto k)
        {
            try
            {
                CzyIstnieje(k);
                uzytkownicy.Add(k);
            } catch (Exception e) { Console.WriteLine($"{e.Message}"); }
        }


        /// <summary>Funkcja sprawdza czy juz istnieje konto o takim loginie w liscie uzytkownikow.Wyrzuca wyjątek jeżeli nie ma takiego konta.</summary>
        /// <param name="k">Konto k.</param>
        /// <exception cref="Exception">Konto o takim loginie juz istnieje!</exception>
        public bool CzyIstnieje(Konto k)
        {
            foreach (Konto konto in uzytkownicy)
                if (k.Login == konto.Login) { return true; }
            return false;
        }

        /// <summary>Obiekt umożliwiający logowanie do istniejącego konta.</summary>
        /// <param name="login">Login.</param>
        /// <param name="haslo">Haslo.</param>
        /// <returns>System.Object.</returns>
        public object Logowanie(string login, string haslo)
        {
            foreach (Konto k in uzytkownicy)
                if (k.Login==login && k.Haslo == haslo) { return k; }
            Konto puste = new Konto();
            return puste;
        }

        /// <summary>Funkcja usówająca konto użytkownika.</summary>
        /// <param name="k">Konto do usunięcia.</param>
        public void UsunKonto(Konto k)
        {
            if (uzytkownicy.Contains(k)) { uzytkownicy.Remove(k); }
        }

        /// <summary>Funkcja podająca liczbę użytkowników.</summary>
        /// <returns>System.Int32.</returns>
        public int liczbaUzytkownikow()
        {
            return uzytkownicy.Count();
        }

        /// <summary>Funkcja sortująca użytkowników.</summary>
        public void Sortuj()
        {
            uzytkownicy.Sort();
        }


        /// <summary>
        /// Zwraca ciąg wyrazów, który reprezentuje bieżący obiekt. Pozwala na wypisywanie.
        /// </summary>
        /// <returns>Zwraca ciąg, który reprezentuje bieżący obiekt.</returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Portal: "+nazwa_portalu);
            sb.AppendLine("Lista uzytkownikow: ");
            foreach (Konto k in uzytkownicy)
            {
                sb.AppendLine(k.ToString());
            }
            return sb.ToString();
        }

        /// <summary>Zapiszs the XML.</summary>
        /// Serializacja XML.
        /// Tworzenie pliku.
        /// <param name="plik">The plik.</param>
        public void ZapiszXML(string plik)
        {
            XmlSerializer xs = new XmlSerializer(typeof(Portal));
            using (StreamWriter sw = new StreamWriter(plik))
            {
                xs.Serialize(sw, this);
            }
        }

        /// <summary>Odczytajs the XML.</summary>
        /// Serializacja XML.Odczyt.
        /// <param name="plik">The plik.</param>
        /// <returns>Object.</returns>
        public object OdczytajXML(string plik)
        {
            Portal p = new Portal();
            StreamReader tr = new StreamReader(plik);
            XmlSerializer serializer = new XmlSerializer(typeof(Portal));
            p = (Portal)serializer.Deserialize(tr);
            tr.Close();
            return p;
        }
        /// <summary>
        /// Funkcja dodaje film do bazy.
        /// </summary>
        /// <param name="f"></param>
       
        public void DodajDoBazy(Film f)
        {
            BazaFilmow.Add(f);
        }


    }
}
