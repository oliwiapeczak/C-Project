﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Projekt
{
    [Serializable]
    public class Konto: IComparable<Konto>
    {
        List<Film> katalog;
        Uzytkownik _uzytkownik;
        string login;
        string haslo;
   
        public List<Film> Katalog { get => katalog; set => katalog = value; }
        [XmlAttribute]
        public string Login { get => login; set => login = value; }
        [XmlAttribute]
        public string Haslo { get => haslo; set => haslo = value; }
        public Uzytkownik Uzytkownik1 { get => _uzytkownik; set => _uzytkownik = value; }

        public Uzytkownik z
        {
            get => default;
            set
            {
            }
        }

        public Uzytkownik Uzytkownik
        {
            get => default;
            set
            {
            }
        }

        /// <summary> Tworzy konstruktor klasy Konto o parametrach: katalog, użytkownik, hasło, login oraz inicjalizuje dane.</summary>
        public Konto()
        {
            Katalog = new List<Film>();
            Uzytkownik1 = null;
            Haslo = null;
            Login = null;
        }

        /// <summary>Drugi konstruktor klasy Konto o następujących parametrach.Inicjalizuje wszystkie dane na podane wartości.</summary>
        /// <param name="uzytkownik">Uzytkownik.</param>
        /// <param name="login">Login.</param>
        /// <param name="haslo">Haslo.</param>
        public Konto(Uzytkownik uzytkownik, string login, string haslo):this()
        {
            this._uzytkownik = uzytkownik;
            SetLogin(login);
            SetHaslo(haslo);
        }
        void SetLogin(string login)
        {
            if (login.Length < 3 || login.Length>20) { throw new Exception("Niepoprawny login!"); } else { Login = login; }
        }
        void SetHaslo(string haslo)
        {
            if (haslo.Length < 5 || haslo.Length>15) { throw new Exception("Niepoprawne hasło!"); } else { Haslo = haslo; }
        }


        /// <summary>Funkcja pozwalająca na dodawanie pozycji.</summary>
        /// <param name="f">film</param>
        public void DodajPozycje(Film f)
        {
            try
            {
                setDodaj(f);
                katalog.Add(f);
            }
            catch(Exception e) { Console.WriteLine(e.Message); }
        }



        /// <summary>
        /// Funkcja sprawdzania czy użytkownik ze względu na ograniczenie wiekowe może dodać dany film.
        /// Wyrzuca wyjątek"Kontrola rodzicielska" jeśli nie może.
        /// </summary>
        /// <param name="f">film</param>
        /// <exception cref="Exception">Kontrola rodzicielska!!!</exception>
        public void setDodaj(Film f)
        {
            if(_uzytkownik.Wiek() < f.Ograniczenie_wiekowe)
            {
                throw new Exception("Kontrola rodzicielska!!!");
            }
        }

        /// <summary>
        /// Funkcja usówania filmów z katalogu.
        /// </summary>
        /// <param name="f">Film</param>
        public void UsunPozycje(Film f)
        {
            if (katalog.Contains(f))
            {
                katalog.Remove(f);
            }
        }

        /// <summary>
        /// Funkcja zwracająca liczbę filmów w katalogu.
        /// </summary>
        /// <returns>System.Int32.</returns>
        public int liczbaPozycji()
        {
            return katalog.Count();
        }

        /// <summary>
        /// Funkcja sortująca.
        /// </summary>
        public void SortujPoTytule()
        {
            katalog.Sort(new TytulComparator());
        }

        /// <summary>
        /// Funkcja porównująca imiona dwóch użytkowników.
        /// </summary>
        /// <param name="other">Drugi użytkownik.</param>
        /// <returns> Zwraca liczbę całkowitą wskazującą, czy imiona są takie same. </returns>
        public int CompareTo(Konto other)
        {
            return this._uzytkownik.Imie.CompareTo(other._uzytkownik.Imie);
        }

        /// <summary>
        /// Zwraca ciąg wyrazów, który reprezentuje bieżący obiekt. Pozwala na wypisywanie.
        /// </summary>
        /// <returns>Zwraca ciąg, który reprezentuje bieżący obiekt.</returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Uzytkownik: " + _uzytkownik);
            sb.AppendLine("Login: "+login);
            sb.AppendLine("Katalog: ");
            foreach (Film f in katalog)
            {
                sb.AppendLine(f.ToString());
            }
            return sb.ToString();
        }

        /// <summary>
        /// Klasa publiczna TytulComparator.Dziediczącząca po IComparer<Film>.
        /// 
        /// </summary>
        /// <seealso cref="System.Collections.Generic.IComparer{Projekt.Film}" />
        public class TytulComparator : IComparer<Film>
        {
            /// <summary>
            /// Funkcja porównująca dwa filmy.
            /// </summary>
            /// <param name="a">Film a.</param>
            /// <param name="b">Film b.</param>
            /// <returns>System.Int32 pozwalający określić czy filmy mają taki sam tytuł.</returns>
            public int Compare(Film a, Film b)
            {
                return string.Compare(a.Tytul, b.Tytul, StringComparison.Ordinal);             
            }
        }




    }

}
