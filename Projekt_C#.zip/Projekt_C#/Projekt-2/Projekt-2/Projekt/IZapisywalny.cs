﻿using System;
using System.Collections.Generic;

namespace Projekt
{
    /// <summary>
    /// Interface IZapisywalny implementujący funkcje zapisu i odczytu XML.
    /// </summary>
    public interface IZapisywalny
    {
        void ZapiszXML(string nazwa);
        object OdczytajXML(string nazwa);
    }
}
