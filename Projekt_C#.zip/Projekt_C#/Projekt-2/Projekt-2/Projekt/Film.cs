﻿using System;
namespace Projekt
{
    /// <summary>
    /// Typ wyliczeniowy dla Gatunku.
    /// </summary>
    public enum Gatunek { Akcja, Przygodowy, Kryminał, Horror, Fantasy, Dokumentalny, Dramat,
        Familijny, Romantyczny, Komedia, Thriller, ScienceFiction }

    /// <summary>
    /// Publiczna klasa Film.
    ///Dziedziczy po IOgraniczalny.
    /// </summary>
    
    [Serializable]
    public class Film: IOgraniczalny, IEquatable<Film>
    {
        string tytul;
        int rok;
        string rezyser;
        int ograniczenie_wiekowe;
        Gatunek gatunek;
        string opis;

        public string Tytul { get => tytul; set => tytul = value; }
        public int Rok { get => rok; set => rok = value; }
        public string Rezyser { get => rezyser; set => rezyser = value; }
        public int Ograniczenie_wiekowe { get => ograniczenie_wiekowe; set => ograniczenie_wiekowe = value; }
        public Gatunek Gatunek { get => gatunek; set => gatunek = value; }
        int IOgraniczalny.ograniczenie_wiekowe { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public string Opis { get => opis; set => opis = value; }

        /// <summary>
        /// Tworzy konstruktor klasy Film o parametrach:tytuł, rok, reżyser,ograniczenie wiekowe oraz inicjalizuje dane.
        /// </summary>
        public Film()
        {
            tytul = null;
            rok = DateTime.Now.Year;
            rezyser = null;
            ograniczenie_wiekowe = 0;
            opis = null;
        }

        /// <summary>
        /// Tworzy konstruktor klasy Film o następujących parametrach.
        /// </summary>
        /// <param name="tytul">Tytuł.</param>
        /// <param name="rezyser">Reżyser.</param>
        /// <param name="rok">Rok.</param>
        /// <param name="ograniczenie_wiekowe">Ograniczenie wiekowe.</param>
        /// <param name="gatunek">Gatunek.</param>
        public Film(string tytul, string rezyser, int rok, int ograniczenie_wiekowe, Gatunek gatunek, string opis)
        {
            Tytul = tytul;
            Rezyser = rezyser;
            try
            {
                SetRok(rok);
                Rok = rok;
            } catch (Exception e) { Console.WriteLine(e.Message); }
            Ograniczenie_wiekowe = ograniczenie_wiekowe;
            Gatunek = gatunek;
            Opis = opis;
        }
        /// <summary>
        /// Funkcja logiczna zwracająca prawdę jeśli tytuł dwóch filmów jest taki sam.
        /// </summary>
        /// <param name="f"></param>
        /// <returns>True or False</returns>
        public bool Equals(Film f)
        {
            return tytul.Equals(f.tytul);
        }

        /// <summary>
        /// Sprawdza czy rok ma 4 znaki i jest późniejszy niż obecny. Wyrzuca wyjątek.
        /// </summary>
        /// <param name="rok">Rok.</param>
        /// <exception cref="Exception">Zly rok!!</exception>
        public void SetRok(int rok)
        {
            if (rok.ToString().Length != 4 || rok>DateTime.Now.Year)
            {
                throw new Exception("Zly rok!!");
            }
        }

        /// <summary>
        /// Zwraca ciąg wyrazów, który reprezentuje bieżący obiekt. Pozwala na wypisywanie.
        /// </summary>
        /// <returns>Zwraca ciąg, który reprezentuje bieżący obiekt.</returns>
        public override string ToString()
        {
            return $"{tytul} - {gatunek}, ograniczenie: {ograniczenie_wiekowe} lat";
        }

        /// <summary>
        /// Tworzy nowy obiekt,który pozwala na skopiowanie zwartości całej instancji.Kopiuje tą instancję.
        /// </summary>
        /// <returns>Nowy obiekt,który jest kopią.</returns>
        public object Clone()
        {
            return this.MemberwiseClone();
        }



    }
}
