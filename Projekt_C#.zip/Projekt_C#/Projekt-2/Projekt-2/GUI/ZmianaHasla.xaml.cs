﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Logika interakcji dla klasy ZmianaHasla.xaml
    /// </summary>
    public partial class ZmianaHasla : Window
    {
        Konto konto;
        Portal portal;

        public ZmianaHasla()
        {
            InitializeComponent();
        }

        public ZmianaHasla(Konto k, Portal p) : this()
        {
            konto = k;
            portal = p;
        }

        private void btn_wroc_Click(object sender, RoutedEventArgs e)
        {
            Dane dane = new Dane(konto, portal);
            Close();
            dane.ShowDialog();
        }

        private void btn_Zatwierdź_Click(object sender, RoutedEventArgs e)
        {
            if (pb_haslo.Password == konto.Haslo)
            {
                if (pb_haslo.Password == pb_nowehaslo.Password)
                {
                    MessageBox.Show("Nowe hasło nie może być takie samo jak stare hasło!", "BŁĄD!", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                else
                {
                    if (pb_nowehaslo.Password.Length < 5 || pb_nowehaslo.Password.Length>15)
                    {
                        MessageBox.Show("Hasło jest za którkie!", "BŁĄD!", MessageBoxButton.OK, MessageBoxImage.Error); return;
                    }
                    else
                    {
                        konto.Haslo = pb_nowehaslo.Password;
                        portal.ZapiszXML("portal.xml");
                        MessageBox.Show("Hasło zostało zmienione", "Sukces!", MessageBoxButton.OK, MessageBoxImage.Information);
                        Dane d = new Dane(konto, portal);
                        Close();
                        d.ShowDialog();
                    }
                }
            } else
            {
                MessageBox.Show("Podano błędne hasło!", "BŁĄD!", MessageBoxButton.OK, MessageBoxImage.Error); return;
            }
        }
    }
}
