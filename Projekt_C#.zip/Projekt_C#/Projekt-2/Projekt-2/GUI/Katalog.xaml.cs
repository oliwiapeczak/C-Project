﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Logika interakcji dla klasy Katalog.xaml
    /// </summary>
    public partial class Katalog : Window
    {
        Portal portal;
        public ObservableCollection<Projekt.Film> filmy;
        public ObservableCollection<Projekt.Film> seriale;
        Konto konto;
        public Katalog()
        {
            InitializeComponent();
        }

        public Katalog(Konto k, Portal p) : this()
        {
            portal = p;
            konto = k;
            filmy = new ObservableCollection<Projekt.Film>();
            foreach (Projekt.Film f in portal.BazaFilmow)
                if (f.GetType() == typeof(Projekt.Film))
                {
                    filmy.Add(f);
                }
            listbox_filmy.ItemsSource = filmy;

            seriale = new ObservableCollection<Projekt.Film>();
            foreach (Projekt.Film s in portal.BazaFilmow)
                if (s.GetType() == typeof(Projekt.Serial))
                {
                    seriale.Add(s);
                }
            listbox_seriale.ItemsSource = seriale;
        }

        private void btn_dodajdoListyF_Click(object sender, RoutedEventArgs e)
        {
            object zaznaczonyF = listbox_filmy.SelectedItem;
            Projekt.Film f = (Projekt.Film)zaznaczonyF;

            if (f == null)
            {
                MessageBox.Show("Proszę wybrać film!", "BŁĄD!", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            else if (konto.Katalog.Contains(f))
            {
                MessageBox.Show("Ten film już istnieje w twoim katalogu", "Uwaga!", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }      
            else 
            {
                
                if (f.Ograniczenie_wiekowe > konto.Uzytkownik1.Wiek())
                {
                    MessageBox.Show("Jesteś zbyt młody/a, aby dodać ten film do twojej listy!", "Ograniczenie wiekowe", MessageBoxButton.OK, MessageBoxImage.Error); return;
                } else
                {
                    konto.DodajPozycje(f);
                    portal.ZapiszXML("portal.xml");
                    MessageBox.Show("Film został pomyślnie dodany!", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
            }
           
        }

        private void btn_dodajdoListyS_Click(object sender, RoutedEventArgs e)
        {
            object zaznaczonyS = listbox_seriale.SelectedItem;
            Projekt.Film s = (Projekt.Film)zaznaczonyS;

            if (zaznaczonyS == null)
            {
                MessageBox.Show("Proszę wybrać serial!", "BŁĄD", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            else if (konto.Katalog.Contains((Projekt.Film)zaznaczonyS))
            {
                MessageBox.Show("Ten serial już istnieje w twoim katalogu!", "Uwaga!", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            else if (s.Ograniczenie_wiekowe > konto.Uzytkownik1.Wiek())
            {
                MessageBox.Show("Jesteś zbyt młody/a, żeby dodać ten serial do swojego katalogu.", "Ograniczenie wiekowe", MessageBoxButton.OK, MessageBoxImage.Error);
                return;

            } else
            {
                konto.DodajPozycje((Projekt.Film)zaznaczonyS);
                portal.ZapiszXML("portal.xml");
                MessageBox.Show("Film został pomyślnie dodany!", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
        }


        private void Button_Wroc_Click(object sender, RoutedEventArgs e)
        {
            użytkownik użytkownik = new użytkownik(konto, portal);
            Close();
            użytkownik.ShowDialog();
        }
        private void Btn_InfoFilm_Click(object sender, RoutedEventArgs e)
        {
            object zaznaczonyF = listbox_filmy.SelectedItem;
            if (zaznaczonyF == null)
            {
                MessageBox.Show("Proszę wybrać film!!", "BŁĄD!", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            Film film = new Film((Projekt.Film)zaznaczonyF, konto, portal);
            Close();
            film.ShowDialog();
        }
        private void Btn_InfoSerial_Click(object sender, RoutedEventArgs e)
        {
            object zaznaczonyS = listbox_seriale.SelectedItem;
            if (zaznaczonyS == null)
            {
                MessageBox.Show("Proszę wybrać serial!!", "BŁĄD!", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            Serial serial = new Serial((Projekt.Serial)zaznaczonyS, konto, portal);
            Close();
            serial.ShowDialog();
        }

        private void CBox_katF_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            filmy = new ObservableCollection<Projekt.Film>();
            string zaznaczony = ((ComboBoxItem)cbox_katF.SelectedItem).Content.ToString();
            if (zaznaczony == "Wszystkie")
            {
                foreach (Projekt.Film f in portal.BazaFilmow)
                    if (f.GetType() == typeof(Projekt.Film))
                    {
                        filmy.Add(f);
                    }
                listbox_filmy.ItemsSource = filmy;
                return;
            }
            else
            {
                foreach (Projekt.Film f in portal.BazaFilmow)
                    if (zaznaczony == f.Gatunek.ToString() && f.GetType()==typeof(Projekt.Film))
                    {
                        filmy.Add(f);
                    }
                listbox_filmy.ItemsSource = filmy;
                return;
            }
        }

        private void Cbox_katS_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            seriale = new ObservableCollection<Projekt.Film>();
            string zaznaczony = ((ComboBoxItem)cbox_katS.SelectedItem).Content.ToString();
            if (zaznaczony == "Wszystkie")
            {
                foreach (Projekt.Film s in portal.BazaFilmow)
                    if (s.GetType() == typeof(Projekt.Serial))
                    {
                        seriale.Add(s);
                    }
                listbox_seriale.ItemsSource = seriale;
                return;
            }
            else
            {
                foreach (Projekt.Film s in portal.BazaFilmow)
                    if (zaznaczony == s.Gatunek.ToString() && s.GetType() == typeof(Projekt.Serial))
                    {
                        seriale.Add(s);
                    }
                listbox_seriale.ItemsSource = seriale;
                return;
            }
        }
    }
}
