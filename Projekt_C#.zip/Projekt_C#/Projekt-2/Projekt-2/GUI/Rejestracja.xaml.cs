﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Logika interakcji dla klasy Rejestracja.xaml
    /// </summary>
    public partial class Rejestracja : Window
    {
        Konto konto = new Konto();
        Uzytkownik u = new Uzytkownik();
        Portal p1 = new Portal();

        public Rejestracja()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            if (txt_imieRej.Text == "" || txt_nazwiskoRej.Text == "" || txt_loginRej.Text == "" || txt_emailRej.Text == "" || date_dataur.SelectedDate.HasValue==false || cb_plec.SelectedItem == null || pb_hasloRej.Password == "")
            {
                MessageBox.Show("Proszę uzupełnić wszystkie pola!", "BŁĄD!", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            } else
            {
                DateTime podanaData = date_dataur.SelectedDate.Value.Date;
                if (pb_hasloRej.Password.Length < 5 || pb_hasloRej.Password.Length>15)
                {
                    MessageBox.Show("Błędna ilość znaków w haśle!", "BŁĄD!", MessageBoxButton.OK, MessageBoxImage.Error); return;
                }
                if (SprawdzMail(txt_emailRej.Text) == false)
                {
                    MessageBox.Show("Podano niepoprawny e-mail!", "BŁĄD!", MessageBoxButton.OK, MessageBoxImage.Error); return;
                } else
                {
                    if (txt_loginRej.Text.Length < 3 || txt_loginRej.Text.Length>20)
                    {
                        MessageBox.Show("Błędna ilość znaków w loginie!", "BŁĄD!", MessageBoxButton.OK, MessageBoxImage.Error); return;
                    } else
                    {
                        if (DateTime.Now.Year-podanaData.Year<5 || podanaData>DateTime.Now)
                        {
                            MessageBox.Show("Błędna data urodzenia! Musisz mieć minumum 5 lat, aby się zarejestrować.", "BŁĄD!", MessageBoxButton.OK, MessageBoxImage.Error); return;
                        } else
                        {
                            if (SetImie(txt_imieRej.Text)==false || SetNazwisko(txt_nazwiskoRej.Text) == false)
                            {
                                MessageBox.Show("Imię lub nazwisko są niepoprawne!", "BŁĄD!", MessageBoxButton.OK, MessageBoxImage.Error); return;
                            } else
                            {
                                u.Imie = txt_imieRej.Text;
                                u.Nazwisko = txt_nazwiskoRej.Text;
                                u.Email = txt_emailRej.Text;
                                if (cb_plec.Name == "Kobieta")
                                {
                                    u.Plec = Plcie.Kobieta;
                                }
                                else { u.Plec = Plcie.Mezczyzna; }
                                u.DataUr = date_dataur.SelectedDate.Value;
                                konto.Uzytkownik1 = u;
                                konto.Login = txt_loginRej.Text;
                                konto.Haslo = pb_hasloRej.Password;
                                Portal p = (Portal)p1.OdczytajXML("portal.xml");
                                if (p.CzyIstnieje(konto)) { MessageBox.Show("Konto o podanym loginie już istnieje!", "BŁĄD!", MessageBoxButton.OK, MessageBoxImage.Error); }
                                else
                                {
                                    p.DodajKonto(konto);
                                    p.ZapiszXML("portal.xml");
                                    MainWindow main = new MainWindow();
                                    Close();
                                    main.ShowDialog();
                                }
                            }
                        }
                    }
                }
            }
        }
        bool SprawdzMail(string mail)
        {
            Regex reg = new Regex(@"^[A-Za-z0-9]+@[a-z]+.[a-z]+$");
            if (reg.IsMatch(mail)) { return true; } else { return false; }
        }
        bool SetImie(string imie)
        {
            Regex reg = new Regex(@"^[A-Z-ŁŻ][a-z-żźćńółęąś]+$");
            if (reg.IsMatch(imie)) { return true; } else { return false; }
        }
        bool SetNazwisko(string nazw)
        {
            Regex reg = new Regex(@"^[A-Z-ŁŻ][a-z-żźćńółęąś]+$");
            if (reg.IsMatch(nazw)) { return true; } else { return false; }
        }

        private void btn_wroc_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            Close();
        }
    }
}
