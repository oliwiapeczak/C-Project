﻿using System;
namespace Projekt
{
    public class Profil
    {
        public Profil()
        {
        }
    }
}
