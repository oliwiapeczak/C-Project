﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Logika interakcji dla klasy użytkownik.xaml
    /// </summary>
    public partial class użytkownik : Window
    {
        public ObservableCollection<Projekt.Film> mojaLista;
        Konto konto;
        Portal portal;

        public użytkownik()
        {
            InitializeComponent();
        }

        public użytkownik(Konto k, Portal p) : this()
        {
            konto = k;
            portal = p;
            mojaLista = new ObservableCollection<Projekt.Film>(k.Katalog);
            listbox_mojaLista.ItemsSource = mojaLista;
            lbl_imieNazwisko_Copy.Content = k.Uzytkownik1.Imie.ToString() + " " + k.Uzytkownik1.Nazwisko.ToString();
            BitmapImage bi;
            //bi = new BitmapImage();
            //bi.BeginInit();
            //bi.UriSource = new Uri(@"C:\Users\julia\OneDrive\Pulpit\studia\Projekt_C#\Projekt-2\Projekt-2\GUI\bin\Debug\piesek.jpg");
            //bi.EndInit();
            //avatar_jpg.Source = bi;
            //avatar_jpg.Stretch = Stretch.Fill;
        }

        private void Btn_wyswietlFilmy_Click(object sender, RoutedEventArgs e)
        {
            Katalog katalog = new Katalog(konto, portal);
            Close();
            katalog.ShowDialog();
        }

        private void Btn_usunPozycje_Click(object sender, RoutedEventArgs e)
        {
            object zaznaczony = listbox_mojaLista.SelectedItem;

            if (zaznaczony == null)
            {
                MessageBox.Show("Proszę wybrać pozycję!", "BŁĄD!", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            else
            {
                konto.UsunPozycje((Projekt.Film)zaznaczony);
                mojaLista = new ObservableCollection<Projekt.Film>(konto.Katalog);
            }

            listbox_mojaLista.ItemsSource = mojaLista;
            portal.ZapiszXML("portal.xml");
        }

        private void Btn_zmienAvatar_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Title = "Wybierz avatar";
            op.Filter = "All supported graphics|*.jpg;*.jpeg;*.png|" +
              "JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|" +
              "Portable Network Graphic (*.png)|*.png";
            if (op.ShowDialog() == true)
            {
                avatar_jpg.Source = new BitmapImage(new Uri(op.FileName));
                avatar_jpg.Stretch = Stretch.Fill;
            }
        }

        private void Btn_wyloguj_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            Close();
            main.ShowDialog();
        }

        private void Btn_dane_Click(object sender, RoutedEventArgs e)
        {
            Dane dane = new Dane(konto, portal);
            Close();
            dane.ShowDialog();
        }
    }
}
