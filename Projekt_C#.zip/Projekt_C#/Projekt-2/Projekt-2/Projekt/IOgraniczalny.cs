﻿using System;
namespace Projekt
{
    /// <summary>
    /// Interface implementuje pole oganiczenie_wiekowe.
    /// </summary>
    public interface IOgraniczalny
    {
        int ograniczenie_wiekowe { get; set; }
    }
}
